<?php

return [
    'adminEmail' => 'admin@example.com',
    'path'=>'http://'.$_SERVER['HTTP_HOST'],

];
